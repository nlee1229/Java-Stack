package com.nicholas.dojosAndNinjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosAndNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
