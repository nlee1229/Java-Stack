package com.Nicholas.GettingFamiliarwithRouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class GettingFamiliarwithRoutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(GettingFamiliarwithRoutingApplication.class, args);
	}

}
