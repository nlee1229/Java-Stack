package com.ObjectMaster;

public class HumanTest {

	public static void main(String[] args) {
		
		// For Human class
		Human h = new Human();
		
		
		Human h2 = new Human();
		h2.attackHuman(h);
		System.out.println(h.displayHealth());
	}

}
