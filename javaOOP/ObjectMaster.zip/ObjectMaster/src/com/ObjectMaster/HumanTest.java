package com.ObjectMaster;

public class HumanTest {

	public static void main(String[] args) {
		
		Human h = new Human();
		
		h.attackHuman();
		System.out.println(h.displayHealth());

	}

}
