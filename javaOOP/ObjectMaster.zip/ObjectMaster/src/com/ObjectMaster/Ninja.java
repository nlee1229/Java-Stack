package com.ObjectMaster;

public class Ninja {

}
