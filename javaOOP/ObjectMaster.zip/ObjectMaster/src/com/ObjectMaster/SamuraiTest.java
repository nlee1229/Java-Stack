package com.ObjectMaster;

public class SamuraiTest {
	
}
