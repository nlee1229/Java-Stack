package com.ObjectMaster;

public class Wizard {

}
