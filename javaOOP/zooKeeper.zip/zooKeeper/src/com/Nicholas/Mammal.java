package com.Nicholas;

// SuperClass----------
public class Mammal {
	
	public int energyLevel = 100;
	
	//printing and returning energy level
	public Integer displayEnergy() {
	System.out.println(energyLevel);
	return energyLevel;
	}
	//-------------------------------
	
	

	
		


}
