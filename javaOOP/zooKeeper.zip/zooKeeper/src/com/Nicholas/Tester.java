package com.Nicholas;

public class Tester {

	public static void main(String[] args) {
		
		// For ZooKeeper Class
		
		Mammal m = new Mammal();
		
		Integer test = m.displayEnergy();
		System.out.println("The current energy level is: " + test);
		
		//-------------------------------------
		
		
		
		
		
	}

}
