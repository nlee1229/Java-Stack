public class FizzBuzzTest {
    public static void main(String[] args) {
        // parameter that we're passing in***
        int number = 1;  
        FizzBuzz iD = new FizzBuzz();
        String word = iD.fizzBuzz(number);
        System.out.println(word);
    }
}